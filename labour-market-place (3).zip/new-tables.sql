create table complaints (
    id bigint primary key generated always as identity,
    user_id bigint,
    user_name text,
    user_phone text,
    subject text,
    details text,
    status text default 'pending',
    reply text,
    created_at timestamptz default now()
);

create table ratings (
    id bigint primary key generated always as identity,
    job_id bigint,
    worker_id bigint,
    client_id bigint,
    client_name text,
    stars int,
    comment text,
    created_at timestamptz default now()
);

alter table complaints enable row level security;
alter table ratings enable row level security;

create policy "open" on complaints for all using (true) with check (true);
create policy "open" on ratings for all using (true) with check (true);
